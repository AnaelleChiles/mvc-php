<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>
        <?= $e?>
    </title>
    <link href="style.css" rel="stylesheet" />
</head>

<body>
    <?= $e ?>
</body>

</html>