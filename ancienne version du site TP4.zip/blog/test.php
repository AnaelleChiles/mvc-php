<?php

function test(){
    try {
        throw new Exception('ma seconde exception');
    }
    catch (Exception $exception){
        throw new Exception('ma troisième exception');

        die($exception->getMessage());
    }

    throw new Exception ('mon exception depuis une fonction');

    //a finir
}